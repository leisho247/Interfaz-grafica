package java.ar.org.centro8.especialidad.web.interfaz.Repositories;

import java.ar.org.centro8.especialidad.web.interfaz.entities.Cursos;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CursoRepository extends CrudRepository<Cursos, Integer> {
    
}

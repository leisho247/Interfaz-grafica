package java.ar.org.centro8.especialidad.web.interfaz.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class AlumnosController {
    
    
}

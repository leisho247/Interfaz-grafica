package java.ar.org.centro8.especialidad.web.interfaz.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "alumnos")
public class Alumnos {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String nombre;
    private String apellido;
    private String edad;
    private int idCurso;


    
    public Alumnos() {
    }



    public Alumnos(Integer id, String nombre, String apellido, String edad, int idCurso) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.idCurso = idCurso;
    }



    public Alumnos(String nombre, String apellido, String edad, int idCurso) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.idCurso = idCurso;
    }



    public Integer getId() {
        return id;
    }



    public void setId(Integer id) {
        this.id = id;
    }



    public String getNombre() {
        return nombre;
    }



    public void setNombre(String nombre) {
        this.nombre = nombre;
    }



    public String getApellido() {
        return apellido;
    }



    public void setApellido(String apellido) {
        this.apellido = apellido;
    }



    public String getEdad() {
        return edad;
    }



    public void setEdad(String edad) {
        this.edad = edad;
    }



    public int getIdCurso() {
        return idCurso;
    }



    public void setIdCurso(int idCurso) {
        this.idCurso = idCurso;
    }



    @Override
    public String toString() {
        return "Alumnos [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", edad=" + edad + ", idCurso="
                + idCurso + "]";
    }


    

}

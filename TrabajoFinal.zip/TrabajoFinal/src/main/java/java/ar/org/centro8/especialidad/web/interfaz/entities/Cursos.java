package java.ar.org.centro8.especialidad.web.interfaz.entities;

public class Cursos {
    
}

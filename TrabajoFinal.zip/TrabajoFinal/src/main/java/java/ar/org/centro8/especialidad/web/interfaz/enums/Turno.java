package java.ar.org.centro8.especialidad.web.interfaz.enums;

public enum Turno {
    MAÑANA,
	TARDE,
	NOCHE
}

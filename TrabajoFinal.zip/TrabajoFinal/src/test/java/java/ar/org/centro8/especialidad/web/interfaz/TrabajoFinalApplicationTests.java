package java.ar.org.centro8.especialidad.web.interfaz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
